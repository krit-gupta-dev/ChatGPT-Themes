// Minimal background script: no tracking, no network. Only cleans up legacy keys on install.
browser.runtime.onInstalled.addListener(() => {});
