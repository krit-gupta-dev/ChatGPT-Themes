(() => {
  const KEY = "wallpaper";
  let layer = null, url = null, observer = null;
  const root = document.documentElement;

  function ensureLayer() {
    if (!layer) { layer = document.createElement("div"); layer.id = "cgt-wallpaper"; layer.setAttribute("aria-hidden", "true"); }
    if (url) layer.style.backgroundImage = `url("${url}")`;
    if (!layer.isConnected) {
      const body = document.body;
      body ? body.parentNode.insertBefore(layer, body) : root.appendChild(layer);
    }
  }
  function apply(dataUrl) {
    url = dataUrl;
    ensureLayer();
    root.classList.add("cgt-on");
    if (!observer) {
      // Only watch direct children of <html> (cheap): React/navigation may replace body or class list.
      observer = new MutationObserver(() => {
        if (!url) return;
        if (!layer.isConnected) ensureLayer();
        if (!root.classList.contains("cgt-on")) root.classList.add("cgt-on");
      });
      observer.observe(root, { childList: true, attributes: true, attributeFilter: ["class"] });
    }
  }
  function remove() {
    url = null;
    if (observer) { observer.disconnect(); observer = null; }
    root.classList.remove("cgt-on");
    if (layer) { layer.remove(); layer.style.backgroundImage = ""; }
  }
  async function load() {
    const { [KEY]: w } = await browser.storage.local.get(KEY);
    w && w.applied && w.dataUrl ? apply(w.dataUrl) : remove();
  }
  browser.storage.onChanged.addListener((c, area) => { if (area === "local" && KEY in c) load(); });
  if (document.body) load(); else document.addEventListener("DOMContentLoaded", load, { once: true });
})();
