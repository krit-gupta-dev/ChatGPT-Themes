const KEY = "wallpaper", MAX = 2560;
const $ = (id) => document.getElementById(id);
const preview = $("preview"), status = $("status"), applyBtn = $("apply"), removeBtn = $("remove");
let pending = null; // data URL chosen but not yet applied

if (new URLSearchParams(location.search).has("tab")) { document.body.classList.add("tabmode"); $("tab").hidden = true; }
$("tab").onclick = (e) => { e.preventDefault(); browser.tabs.create({ url: browser.runtime.getURL("popup.html?tab=1") }); window.close(); };

function setStatus(t, cls = "") { status.textContent = t; status.className = "status " + cls; }
function showPreview(u) { preview.style.backgroundImage = u ? `url("${u}")` : ""; preview.classList.toggle("empty", !u); }

// Downscale very large images so storage stays small and the page stays fast.
function processImage(file) {
  return new Promise((res, rej) => {
    const img = new Image(), src = URL.createObjectURL(file);
    img.onload = () => {
      const s = Math.min(1, MAX / Math.max(img.width, img.height));
      const c = document.createElement("canvas");
      c.width = Math.round(img.width * s); c.height = Math.round(img.height * s);
      c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
      URL.revokeObjectURL(src);
      res(c.toDataURL(file.type === "image/png" ? "image/png" : "image/jpeg", 0.92));
    };
    img.onerror = () => { URL.revokeObjectURL(src); rej(new Error("Could not read image")); };
    img.src = src;
  });
}

async function refresh() {
  const { [KEY]: w } = await browser.storage.local.get(KEY);
  showPreview(pending || w?.dataUrl);
  applyBtn.disabled = !(pending || (w && !w.applied));
  removeBtn.disabled = !w;
  if (pending) setStatus("Preview ready — click Apply Wallpaper");
  else if (w?.applied) setStatus("Wallpaper applied", "ok");
  else setStatus("No wallpaper selected");
}

$("upload").onclick = () => $("file").click();
$("file").onchange = async (e) => {
  const f = e.target.files[0]; e.target.value = "";
  if (!f) return;
  if (!/^image\/(png|jpeg|webp)$/.test(f.type) && !/\.(png|jpe?g|webp)$/i.test(f.name)) return setStatus("Please choose a PNG, JPG or WebP image", "err");
  setStatus("Processing…");
  try { pending = await processImage(f); } catch (err) { return setStatus(err.message, "err"); }
  refresh();
};
applyBtn.onclick = async () => {
  const { [KEY]: w } = await browser.storage.local.get(KEY);
  const dataUrl = pending || w?.dataUrl; if (!dataUrl) return;
  try { await browser.storage.local.set({ [KEY]: { dataUrl, applied: true, updated: Date.now() } }); }
  catch (err) { return setStatus("Could not save image: " + err.message, "err"); }
  pending = null; refresh();
};
removeBtn.onclick = async () => { pending = null; await browser.storage.local.remove(KEY); refresh(); };
refresh();
$("credit").onclick = (e) => { e.preventDefault(); browser.tabs.create({ url: "https://github.com/krit-gupta-dev" }); window.close(); };
