# ChatGPT Themes (Firefox extension)

Set your own image as the wallpaper behind ChatGPT conversations. No preset wallpapers — nothing changes until you upload and apply an image.

## Install temporarily (about:debugging)
1. Unzip this folder.
2. Open Firefox and go to `about:debugging#/runtime/this-firefox`.
3. Click **Load Temporary Add-on…** and select `manifest.json` in this folder.
4. Pin the extension (puzzle icon → ChatGPT Themes → Pin to Toolbar).
5. When asked, allow access to chatgpt.com (Firefox MV3 may show the host permission as optional: right-click the icon → *Always allow on chatgpt.com*, or enable it in about:addons → Permissions).

Temporary add-ons are removed when Firefox closes. To keep it across restarts, either sign it on addons.mozilla.org (unlisted is fine) or use Firefox Developer Edition/Nightly with `xpinstall.signatures.required = false` and install the zipped folder as an `.xpi`. Your saved wallpaper persists across restarts with a permanent install.

## Use
1. Click the toolbar icon → **Upload Image** (PNG, JPG, JPEG, WebP).
2. Check the preview, then **Apply Wallpaper**. Open chatgpt.com tabs update instantly.
3. **Remove** restores the original ChatGPT look.
If the popup closes while the file picker opens (some systems), use the "Open in a tab" link.

## How it works
- `popup.js` downscales large images (max 2560px) and saves them in `browser.storage.local` (`unlimitedStorage`), on your device only.
- `content.js` adds one fixed, click-through layer (`pointer-events: none`) behind the page and makes only the main chat surfaces transparent. Messages get a soft translucent backing for readability, tuned for light and dark mode. A tiny MutationObserver (watching only `<html>`'s direct children/class) restores the layer if ChatGPT re-renders.
- Permissions: `storage`, `unlimitedStorage`, and host access to `https://chatgpt.com/*` only. No network requests, no analytics.

## Files
manifest.json · popup.html/css/js · content.js/css · background.js · icons/

## Credits
Developer: Krit Gupta
